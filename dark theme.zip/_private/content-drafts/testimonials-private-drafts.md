# Woodex Interior — private testimonial draft bank

**Status: PRIVATE DRAFT — NOT FOR PUBLICATION**

These are structured placeholders for owner/client verification. Replace each placeholder only after confirming the client's identity, wording, project permission, and publication consent. Do not add these entries to public HTML, schema, Google Business Profile, or social media until approved.

## Verification checklist

- Confirm the client gave permission to publish.
- Confirm the project type and city.
- Replace the draft with the client's own words or an approved edited version.
- Add the client's real name or approved descriptor only if permitted.
- Record the approval date privately.

## Draft placeholders

1. **Residential / Lahore / client name pending** — “The design process gave us a clear plan for the home before work started. Final wording pending client approval.”
2. **Kitchen renovation / Lahore / client name pending** — “The kitchen layout made better use of the available storage and worktop space. Final wording pending client approval.”
3. **Bedroom design / Lahore / client name pending** — “The bedroom feels calmer and more practical now. Final wording pending client approval.”
4. **Apartment interior / Islamabad / client name pending** — “The team helped us make the apartment feel larger without overloading it with furniture. Final wording pending client approval.”
5. **Home renovation / Lahore / client name pending** — “The staged approach helped us understand what would happen next. Final wording pending client approval.”
6. **Office interior / Lahore / client name pending** — “The office plan balanced focused work, meetings and storage. Final wording pending client approval.”
7. **Office fit-out / Karachi / client name pending** — “The handover process was organised and the scope was clear. Final wording pending client approval.”
8. **Retail design / Lahore / client name pending** — “The customer-flow discussion improved the way the shop works. Final wording pending client approval.”
9. **Showroom fit-out / Faisalabad / client name pending** — “The display and lighting plan made the showroom easier to navigate. Final wording pending client approval.”
10. **Restaurant interior / Lahore / client name pending** — “The seating, service and lighting decisions were considered together. Final wording pending client approval.”
11. **Café interior / Lahore / client name pending** — “The café feels welcoming and works better during busy periods. Final wording pending client approval.”
12. **Beauty salon design / Lahore / client name pending** — “The plan created a more comfortable journey for both clients and staff. Final wording pending client approval.”
13. **Clinic setup / Lahore / client name pending** — “The reception and waiting-area planning made the clinic feel calmer and more functional. Final wording pending client approval.”
14. **Dental clinic fit-out / Lahore / client name pending** — “The room planning kept privacy, circulation and finishes in view. Final wording pending client approval.”
15. **Pharmacy fit-out / Lahore / client name pending** — “The counter, storage and customer-flow decisions were practical for daily use. Final wording pending client approval.”
16. **Diagnostic centre / Lahore / client name pending** — “The team helped coordinate the interior plan with the operational requirements. Final wording pending client approval.”
17. **3D visualization / Pakistan / client name pending** — “The renders helped us make material and lighting decisions before construction. Final wording pending client approval.”
18. **Turnkey design-build / Lahore / client name pending** — “Having one coordinated point of contact made the project easier to follow. Final wording pending client approval.”
19. **Commercial renovation / Multan / client name pending** — “The phased plan helped us keep the work organised around the business. Final wording pending client approval.”
20. **Furniture and joinery coordination / Lahore / client name pending** — “The joinery was planned around the room instead of treated as an afterthought. Final wording pending client approval.”

## Owner approval log

| Drafts | Client / approved descriptor | Project | Permission confirmed | Approved wording | Approval date |
|---|---|---|---|---|---|
| 1–20 | Pending | Pending | No | Pending | Pending |
